package beans;

public class Student_data {
    private int id,year,s_adm_yr,s_hsc_pass,s_ssc_tech,cerno,shift;
    private String rollno,s_regular,programme,s_email,phone_no,s_name,s_sex,s_dob,s_add,s_category,s_ut_ru,s_l_school,s_remark,reg_cand_no,caste,dob_place,state,dob_words,adm_date,progress,conduct,leaving_date,studying_when,reason_of_learning,photo,term,ncode1,ncode2,status1,status2,stcr1,stcr2,shift2007,sign,username,password; 

    public int getShift() {
        return shift;
    }

    public void setShift(int shift) {
        this.shift = shift;
    }
    
    public String getS_email() {
        return s_email;
    }

    public void setS_email(String s_email) {
        this.s_email = s_email;
    }

    public String getPhone_no() {
        return phone_no;
    }

    public void setPhone_no(String phone_no) {
        this.phone_no = phone_no;
    }

    public int getS_adm_yr() {
        return s_adm_yr;
    }

    public void setS_adm_yr(int s_adm_yr) {
        this.s_adm_yr = s_adm_yr;
    }

    public int getS_hsc_pass() {
        return s_hsc_pass;
    }

    public void setS_hsc_pass(int s_hsc_pass) {
        this.s_hsc_pass = s_hsc_pass;
    }

    public int getS_ssc_tech() {
        return s_ssc_tech;
    }

    public void setS_ssc_tech(int s_ssc_tech) {
        this.s_ssc_tech = s_ssc_tech;
    }

    public int getCerno() {
        return cerno;
    }

    public void setCerno(int cerno) {
        this.cerno = cerno;
    }

    public String getS_regular() {
        return s_regular;
    }

    public void setS_regular(String s_regular) {
        this.s_regular = s_regular;
    }

    public String getS_name() {
        return s_name;
    }

    public void setS_name(String s_name) {
        this.s_name = s_name;
    }

    public String getS_sex() {
        return s_sex;
    }

    public void setS_sex(String s_sex) {
        this.s_sex = s_sex;
    }

    public String getS_dob() {
        return s_dob;
    }

    public void setS_dob(String s_dob) {
        this.s_dob = s_dob;
    }

    public String getS_add() {
        return s_add;
    }

    public void setS_add(String s_add) {
        this.s_add = s_add;
    }

    public String getS_category() {
        return s_category;
    }

    public void setS_category(String s_category) {
        this.s_category = s_category;
    }

    public String getS_ut_ru() {
        return s_ut_ru;
    }

    public void setS_ut_ru(String s_ut_ru) {
        this.s_ut_ru = s_ut_ru;
    }

    public String getS_l_school() {
        return s_l_school;
    }

    public void setS_l_school(String s_l_school) {
        this.s_l_school = s_l_school;
    }

    public String getS_remark() {
        return s_remark;
    }

    public void setS_remark(String s_remark) {
        this.s_remark = s_remark;
    }

    public String getReg_cand_no() {
        return reg_cand_no;
    }

    public void setReg_cand_no(String reg_cand_no) {
        this.reg_cand_no = reg_cand_no;
    }

    public String getCaste() {
        return caste;
    }

    public void setCaste(String caste) {
        this.caste = caste;
    }

    public String getDob_place() {
        return dob_place;
    }

    public void setDob_place(String dob_place) {
        this.dob_place = dob_place;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDob_words() {
        return dob_words;
    }

    public void setDob_words(String dob_words) {
        this.dob_words = dob_words;
    }

    public String getAdm_date() {
        return adm_date;
    }

    public void setAdm_date(String adm_date) {
        this.adm_date = adm_date;
    }

    public String getProgress() {
        return progress;
    }

    public void setProgress(String progress) {
        this.progress = progress;
    }

    public String getConduct() {
        return conduct;
    }

    public void setConduct(String conduct) {
        this.conduct = conduct;
    }

    public String getLeaving_date() {
        return leaving_date;
    }

    public void setLeaving_date(String leaving_date) {
        this.leaving_date = leaving_date;
    }

    public String getStudying_when() {
        return studying_when;
    }

    public void setStudying_when(String studying_when) {
        this.studying_when = studying_when;
    }

    public String getReason_of_learning() {
        return reason_of_learning;
    }

    public void setReason_of_learning(String reason_of_learning) {
        this.reason_of_learning = reason_of_learning;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getNcode1() {
        return ncode1;
    }

    public void setNcode1(String ncode1) {
        this.ncode1 = ncode1;
    }

    public String getNcode2() {
        return ncode2;
    }

    public void setNcode2(String ncode2) {
        this.ncode2 = ncode2;
    }

    public String getStatus1() {
        return status1;
    }

    public void setStatus1(String status1) {
        this.status1 = status1;
    }

    public String getStatus2() {
        return status2;
    }

    public void setStatus2(String status2) {
        this.status2 = status2;
    }

    public String getStcr1() {
        return stcr1;
    }

    public void setStcr1(String stcr1) {
        this.stcr1 = stcr1;
    }

    public String getStcr2() {
        return stcr2;
    }

    public void setStcr2(String stcr2) {
        this.stcr2 = stcr2;
    }

    public String getShift2007() {
        return shift2007;
    }

    public void setShift2007(String shift2007) {
        this.shift2007 = shift2007;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public float getS_ssc_mark() {
        return s_ssc_mark;
    }

    public void setS_ssc_mark(float s_ssc_mark) {
        this.s_ssc_mark = s_ssc_mark;
    }

    public float getS_hsc_mark() {
        return s_hsc_mark;
    }

    public void setS_hsc_mark(float s_hsc_mark) {
        this.s_hsc_mark = s_hsc_mark;
    }
    private float s_ssc_mark,s_hsc_mark;

    public String getProgramme() {
        return programme;
    }
    
    public void setProgramme(String programme) {
        this.programme = programme;
    }
    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }
    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getRollno() {
        return rollno;
    }

    public void setRollno(String rollno) {
        this.rollno = rollno;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    
}
