/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author sarvadnya
 */
public class Exam_reg {
    private String regno,course_code,ex_reg_date,prog,ex_reg_term;
    private int ex_exmt,ex_th,ex_pt,ex_tw,ex_pr,ex_or,ex_det,ex_back,ex_cancel,ex_pass,Ex,id,ex_reg_year,shift;

    public int getShift() {
        return shift;
    }

    public void setShift(int shift) {
        this.shift = shift;
    }
    
    public String getEx_reg_term() {
        return ex_reg_term;
    }

    public void setEx_reg_term(String ex_reg_term) {
        this.ex_reg_term = ex_reg_term;
    }
    

    public int getEx_reg_year() {
        return ex_reg_year;
    }

    public void setEx_reg_year(int ex_reg_year) {
        this.ex_reg_year = ex_reg_year;
    }

    public String getRegno() {
        return regno;
    }

    public void setRegno(String regno) {
        this.regno = regno;
    }

   public String getCourse_code() {
        return course_code;
    }

    public void setCourse_code(String course_code) {
        this.course_code = course_code;
    }

    public String getEx_reg_date() {
        return ex_reg_date;
    }

    public void setEx_reg_date(String ex_reg_date) {
        this.ex_reg_date = ex_reg_date;
    }

    public String getProg() {
        return prog;
    }

    public void setProg(String prog) {
        this.prog = prog;
    }

    public int getEx_exmt() {
        return ex_exmt;
    }

    public void setEx_exmt(int ex_exmt) {
        this.ex_exmt = ex_exmt;
    }

    public int getEx_th() {
        return ex_th;
    }

    public void setEx_th(int ex_th) {
        this.ex_th = ex_th;
    }

    public int getEx_pt() {
        return ex_pt;
    }

    public void setEx_pt(int ex_pt) {
        this.ex_pt = ex_pt;
    }

    public int getEx_tw() {
        return ex_tw;
    }

    public void setEx_tw(int ex_tw) {
        this.ex_tw = ex_tw;
    }

    public int getEx_pr() {
        return ex_pr;
    }

    public void setEx_pr(int ex_pr) {
        this.ex_pr = ex_pr;
    }

    public int getEx_or() {
        return ex_or;
    }

    public void setEx_or(int ex_or) {
        this.ex_or = ex_or;
    }

    public int getEx_det() {
        return ex_det;
    }

    public void setEx_det(int ex_det) {
        this.ex_det = ex_det;
    }

    public int getEx_back() {
        return ex_back;
    }

    public void setEx_back(int ex_back) {
        this.ex_back = ex_back;
    }

    public int getEx_cancel() {
        return ex_cancel;
    }

    public void setEx_cancel(int ex_cancel) {
        this.ex_cancel = ex_cancel;
    }

    public int getEx_pass() {
        return ex_pass;
    }

    public void setEx_pass(int ex_pass) {
        this.ex_pass = ex_pass;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEx() {
        return Ex;
    }

    public void setEx(int Ex) {
        this.Ex = Ex;
    }
    
}
